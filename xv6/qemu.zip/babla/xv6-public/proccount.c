// File: proccount.c
#include "types.h"
#include "stat.h"
#include "user.h"

int
main(void)
{
  printf(1, "Number of active processes: %d\n", getprocesscount());
  
  // Show that we can't access kernel resources directly
  // The following line would cause a compilation error if uncommented:
  // struct ptable ptable;  // Error: ptable is not accessible from user space!
  
  // Create a child process to show count changing
  if(fork() == 0) {
    // Child process
    printf(1, "After fork, process count: %d\n", getprocesscount());
    exit();
  } else {
    // Parent process
    wait();
  }
  
  printf(1, "After child exits, process count: %d\n", getprocesscount());
  exit();
}

