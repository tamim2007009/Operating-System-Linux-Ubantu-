#include "types.h"
#include "stat.h"
#include "user.h"

void spin(int pid) {
  for (int i = 0; i < 10; i++) {
    printf(1, "Process %d running iteration %d\n", pid, i);
    sleep(10); // Give up CPU so scheduler can switch processes
  }
}

int main() {
  int pid, i;

  // Create multiple processes
  for (i = 0; i < 3; i++) { // 3 processes for testing
    pid = fork();
    if (pid < 0) {
      printf(1, "Fork failed!\n");
      exit();
    } else if (pid == 0) {
      // Child process: run a task
      spin(getpid());
      exit();
    }
  }

  // Parent waits for all children to finish
  for (i = 0; i < 3; i++) {
    wait();
  }

  printf(1, "All processes finished\n");
  exit();
}

